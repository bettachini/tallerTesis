import os
import PyPDF2

def merge_pdfs_in_directory(directory, output_path):
    merger = PyPDF2.PdfMerger()
    for filename in os.listdir(directory):
        if filename.endswith('.pdf'):
            pdf_path = os.path.join(directory, filename)
            merger.append(pdf_path)
    merger.write(output_path)
    merger.close()

if __name__ == "__main__":
    # Directorio que contiene los archivos PDF que quieres unir
    pdf_directory = r"D:\Tesis Matias\graficos"
    
    # Ruta de salida para el archivo PDF combinado
    output_file = "pdf_combinado.pdf"
    
    # Llamada a la función para combinar los archivos PDF en el directorio especificado
    merge_pdfs_in_directory(pdf_directory, output_file)
