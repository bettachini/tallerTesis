import psycopg2
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from sklearn.linear_model import LinearRegression

# Conectar a la base de datos
conn = psycopg2.connect(
    dbname="Tesis",
    user="postgres",
    password="postgres",
    host="localhost"
)

# Consulta SQL para extraer los datos de la tabla
query = """
    SELECT "Year", "DOY", "lat", "long", "h"
    FROM estaciones_individuales.estacion_igm1
    ORDER BY "Year", "DOY" """

# Leer los datos en un DataFrame de pandas
df = pd.read_sql(query, conn)

# Cerrar la conexión a la base de datos
conn.close()

# Crear un MultiIndex para representar todas las combinaciones de Year y DOY
index = pd.MultiIndex.from_product([df['Year'].unique(), range(1, 366)], names=['Year', 'DOY'])

# Reindexar el DataFrame para incluir todas las combinaciones de Year y DOY
df = df.set_index(['Year', 'DOY']).reindex(index)

# Definir la función para ajustar una regresión lineal a un sector
def ajustar_regresion(df):
    X = np.array(df.index.get_level_values('DOY')).reshape(-1, 1)
    y = df['h']
    # Eliminar NaNs solo para el ajuste de la regresión
    X_clean = X[~np.isnan(y)]
    y_clean = y[~np.isnan(y)]
    regresion = LinearRegression().fit(X_clean, y_clean)
    return regresion.coef_[0], regresion.intercept_

# Graficar la serie temporal
plt.figure(figsize=(12, 6))
plt.plot(df.index.get_level_values('Year').astype(str) + '-' + df.index.get_level_values('DOY').astype(str), df['h'], marker='o', linestyle='-', label='Altura')

# Filtrar los datos para sectores con al menos un año corrido
sectores_con_datos = df.groupby('Year').filter(lambda x: len(x) >= 365)

for year, group in sectores_con_datos.groupby('Year'):
    coeficiente, interseccion = ajustar_regresion(group)
    # Solo ajustar la regresión para el rango de valores de la serie temporal original
    min_doy, max_doy = group.index.get_level_values('DOY').min(), group.index.get_level_values('DOY').max()
    x_regresion = np.arange(min_doy, max_doy + 1)
    # Construir etiquetas del eje x para las regresiones lineales
    labels_x = [f"{year}-{doy}" for doy in x_regresion]
    plt.plot(labels_x, coeficiente * x_regresion + interseccion, label=f'Regresión {year}')

plt.title('Alturas por Día del Año')
plt.xlabel('Día del Año - Año')
plt.ylabel('Altura')
plt.xticks(rotation=90)  # Rotar las etiquetas del eje x para mayor claridad
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.show()


