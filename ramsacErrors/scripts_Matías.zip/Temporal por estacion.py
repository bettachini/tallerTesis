import psycopg2
import pandas as pd
import matplotlib.pyplot as plt

# Conectar a la base de datos
conn = psycopg2.connect(
    dbname="Tesis",
    user="postgres",
    password="postgres",
    host="localhost"
)

# Consulta SQL para extraer los datos de la tabla
query = """
    SELECT "Year", "DOY", "lat", "long", "h"
    FROM estaciones_individuales.estacion_igm1
    ORDER BY "Year", "DOY" """


# Leer los datos en un DataFrame de pandas
df = pd.read_sql(query, conn)

# Cerrar la conexión a la base de datos
conn.close()

# Crear un MultiIndex para representar todas las combinaciones de Year y DOY
index = pd.MultiIndex.from_product([df['Year'].unique(), range(1, 366)], names=['Year', 'DOY'])

# Reindexar el DataFrame para incluir todas las combinaciones de Year y DOY
df = df.set_index(['Year', 'DOY']).reindex(index)

# Graficar la serie temporal
plt.figure(figsize=(12, 6))
plt.plot(df.index.get_level_values('Year').astype(str) + '-' + df.index.get_level_values('DOY').astype(str), df['h'], marker='o', linestyle='-')
plt.title('Alturas por Día del Año')
plt.xlabel('Día del Año - Año')
plt.ylabel('Altura')
plt.xticks(rotation=90)  # Rotar las etiquetas del eje x para mayor claridad
plt.grid(True)
plt.tight_layout()
plt.show()