import os
import psycopg2
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as plticker

# Conectar a la base de datos
conn = psycopg2.connect(
    dbname="Tesis",
    user="postgres",
    password="postgres",
    host="localhost"
)

# Obtener la lista de tablas en el esquema estaciones_individuales
cursor = conn.cursor()
cursor.execute("SELECT table_name FROM information_schema.tables WHERE table_schema = 'estaciones_individuales'")
tables = cursor.fetchall()
cursor.close()

# Iterar sobre las tablas
for table in tables:
    table_name = table[0]
    # Consulta SQL para extraer los datos de la tabla actual
    query = f"""
        SELECT "Year", "DOY", "lat", "long", "h"
        FROM estaciones_individuales.{table_name}
        ORDER BY "Year", "DOY" """
    
    # Leer los datos en un DataFrame de pandas
    df = pd.read_sql(query, conn)
    
    # Crear un MultiIndex para representar todas las combinaciones de Year y DOY
    index = pd.MultiIndex.from_product([df['Year'].unique(), range(1, 366)], names=['Year', 'DOY'])
    
    # Reindexar el DataFrame para incluir todas las combinaciones de Year y DOY
    df = df.set_index(['Year', 'DOY']).reindex(index)
    
    # Graficar la serie temporal con marcadores pequeños
    plt.figure(figsize=(12, 6))
    plt.plot(df.index.get_level_values('Year').astype(str) + '-' + df.index.get_level_values('DOY').astype(str), df['h'], linestyle='-', marker='o', markersize=3)
    plt.title(f'Alturas por Día del Año - {table_name}')
    plt.xlabel('Día del Año - Año')
    plt.ylabel('Altura')
    plt.xticks(rotation=90)  # Rotar las etiquetas del eje x para mayor claridad
    plt.grid(True)
    plt.gca().xaxis.set_major_locator(plticker.MultipleLocator(365))  # Mostrar solo las etiquetas para DOY igual a 1
    plt.tight_layout()
    
    # Guardar el gráfico en un archivo PDF
    output_path = r'D:\Tesis Matias\graficos'
    if not os.path.exists(output_path):
        os.makedirs(output_path)
    plt.savefig(os.path.join(output_path, f'{table_name}.pdf'), dpi=900)
    plt.close()

# Cerrar la conexión a la base de datos
conn.close()

